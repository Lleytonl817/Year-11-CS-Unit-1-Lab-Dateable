
import java.util.Scanner;
public class Dateable {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int myAge;
        System.out.print("Enter your age: ");
        myAge = scan.nextInt();
        int newAge = myAge/2 + 7;
        System.out.println(myAge + "-year olds should date somebody who is at least" + newAge + "years old.");
    }
}
